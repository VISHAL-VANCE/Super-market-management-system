
<html>
  <head>
    <title>Invoice Portal</title>
  </head>
  <body>
    <h1>Enter the name of product to Add in the Bill</h1>
    <form method="POST" action="invoicepage.php">
    PRODUCT<input type="text" id="txt1" name="txt1"/><br>
    QUANTITY<input type="text" id="txt2" name="txt2"/>
    <input type="submit" name="btn" value="Add" /><br>
    <?php
   $con = mysqli_connect('localhost','root','','supermarket');
   $tot=0;
    echo "<table border='1'>
    <tr>
    <th>Product Name</th>
    <th>Price</th>
    <th>Quantity</th>
    </tr>";
 if(isset($_POST["btn"])){
  
    if (!$con)
    {
        die('Could not connect: ' . mysqli_error());
    }

    else{
    $a=$_POST["txt1"];
    $sql = "Select Pname,Price FROM product where Pname='$a';";
    
    $result = mysqli_query($con,$sql);

    while($row = mysqli_fetch_array($result)){
      $b=$_POST["txt2"];
      mysqli_query($con,"INSERT INTO invoice (Pname,Pprice,Pquantity) VALUES ('$row[0]','$row[1]','$b')");
    }
}
 }
 $result = mysqli_query($con,"SELECT * FROM invoice");

 while($row = mysqli_fetch_array($result))
 {
     echo "<tr>";
     echo "<td>".$row[0]."</td>" . "<td>" . $row[1]."</td>"."<td>" . $row[2]."</td>";
     echo "</tr>";
     $tot=$tot+($row[1]*$row[2]);
 } 
 echo "<td></td><td>Total</td>" . "<td>" . $tot."</td>";
   echo "</table>";
   mysqli_close($con);
?>
    </form>
    <form action="invoicepage.php">
    <input type='submit' name='invoice' value='Confirm Purchase' >
</form>
  </body>
  </html>
  